# jar-string-editor


##### Rodando localmente:
Requisitos: `node`, `yarn (ou npm)`
- Clone o repositório usando: `git clone https://github.com/leonardosnt/jar-string-editor`
- Vá até o diretório usando: `cd jar-string-editor`
- Instale as dependências usando: `yarn`
- Inicie o servidor de testes usando: `yarn start`
- Editar o código e o site será automaticamente recarregado.

## License
Copyright (C) leonardosnt <leonrdsnt@gmail.com>  
Licensed under the GPL-2.0 license. See LICENSE file in the project root for full license information.