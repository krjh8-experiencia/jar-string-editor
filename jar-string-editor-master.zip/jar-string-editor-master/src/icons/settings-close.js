import React from "react";

export default () => (
  <svg height="16" width="16" viewBox="0 0 16 16">
    <path
      d="M9.414 8l3.531-3.531a1 1 0 1 0-1.414-1.414L8 6.586 4.469 3.055a1 1 0 1 0-1.414 1.414L6.586 8l-3.531 3.531a1 1 0 1 0 1.414 1.414L8 9.414l3.531 3.531a1 1 0 1 0 1.414-1.414z"
      fill="context-fill"
    />
  </svg>
);
